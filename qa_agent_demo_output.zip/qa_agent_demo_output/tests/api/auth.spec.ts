import { test, expect } from '@playwright/test';

/**
 * API tests hit the backend directly via Playwright's `request` fixture.
 * Faster and more stable than UI tests for contract/boundary verification.
 */

const USER = process.env.TEST_USER ?? 'active@test.com';
const PASS = process.env.TEST_PASS ?? 'ValidPass123!';

test.describe('REQ-2 API: Input validation', () => {
  test('TC-008: 300-char email rejected with 400 @P1 @boundary', async ({ request }) => {
    const longLocal = 'a'.repeat(290);
    const res = await request.post('/api/auth/login', {
      data: { email: `${longLocal}@x.com`, password: 'ValidPass123!' },
    });
    expect(res.status()).toBe(400);
    const body = await res.json();
    expect(JSON.stringify(body).toLowerCase()).toMatch(/email|length/);
  });

  test('TC-011: 8-char password accepted @P1 @boundary', async ({ request }) => {
    // Requires a seeded user whose password is exactly 8 chars
    const res = await request.post('/api/auth/login', {
      data: { email: 'shortpass@test.com', password: 'Pass123!' },
    });
    expect(res.status()).toBe(200);
    const body = await res.json();
    expect(body.user).toBeDefined();
    expect(body.sessionExpiresAt).toBeDefined();
  });

  test('TC-012: 129-char password rejected @P1 @boundary', async ({ request }) => {
    const res = await request.post('/api/auth/login', {
      data: { email: USER, password: 'A'.repeat(129) },
    });
    expect(res.status()).toBe(400);
  });
});

test.describe('REQ-3 API: Rate limiting', () => {
  test('TC-013: 6th failed attempt returns 429 with Retry-After @P0 @boundary', async ({ request }) => {
    const email = `ratelimit-${Date.now()}@test.com`; // unique to avoid cross-test pollution

    // 5 failed attempts — all 401
    for (let i = 1; i <= 5; i++) {
      const res = await request.post('/api/auth/login', {
        data: { email, password: 'wrongpass' },
      });
      expect(res.status(), `attempt ${i}`).toBe(401);
    }

    // 6th attempt — 429
    const limited = await request.post('/api/auth/login', {
      data: { email, password: 'wrongpass' },
    });
    expect(limited.status()).toBe(429);
    const retryAfter = limited.headers()['retry-after'];
    expect(retryAfter, 'Retry-After header required').toBeDefined();
    expect(Number.parseInt(retryAfter!, 10)).toBeGreaterThan(0);
  });

  test('TC-014: rate limit is per-email, not per-IP @P0 @security', async ({ request }) => {
    const emailA = `limitA-${Date.now()}@test.com`;
    const emailB = USER; // known-valid user

    // Burn attempts for emailA
    for (let i = 0; i < 5; i++) {
      await request.post('/api/auth/login', { data: { email: emailA, password: 'x' } });
    }

    // emailB from the same client must still succeed
    const res = await request.post('/api/auth/login', {
      data: { email: emailB, password: PASS },
    });
    expect(res.status(), 'different email must not be rate-limited').toBe(200);
  });

  test('TC-015: successful login resets failed-attempt counter @P1 @functional', async ({ request }) => {
    // 4 failures
    for (let i = 0; i < 4; i++) {
      await request.post('/api/auth/login', { data: { email: USER, password: 'wrong' } });
    }
    // Successful login
    const ok = await request.post('/api/auth/login', { data: { email: USER, password: PASS } });
    expect(ok.status()).toBe(200);

    // 3 more failures — must NOT hit 429 (counter was reset)
    for (let i = 0; i < 3; i++) {
      const r = await request.post('/api/auth/login', { data: { email: USER, password: 'wrong' } });
      expect(r.status(), `post-reset attempt ${i + 1}`).toBe(401);
    }
  });
});

test.describe('REQ-4 API: Reset token', () => {
  test('TC-019: token older than 1 hour rejected @P0 @boundary', async ({ request }) => {
    // Test seam: ask the server to mint a token dated 61 minutes ago
    const seam = await request.post('/api/test/issue-reset-token', {
      data: { email: 'reset@test.com', ageMinutes: 61 },
    });
    expect(seam.ok()).toBeTruthy();
    const { token } = await seam.json();

    const res = await request.post('/api/auth/reset', {
      data: { token, password: 'NewValidPass1!' },
    });
    expect(res.status()).toBe(400);
    const body = await res.json();
    expect(JSON.stringify(body).toLowerCase()).toMatch(/expire|invalid/);
  });
});
