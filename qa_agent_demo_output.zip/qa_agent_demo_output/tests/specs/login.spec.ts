import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';
import { LoginPage } from '../pages/LoginPage';

const USER = process.env.TEST_USER ?? 'active@test.com';
const PASS = process.env.TEST_PASS ?? 'ValidPass123!';

test.describe('REQ-1: Login', () => {
  test('TC-001: succeeds with valid credentials @P0 @functional', async ({ page, context }) => {
    const login = new LoginPage(page);
    await login.goto();
    await login.login(USER, PASS);

    await expect(page).toHaveURL(/\/dashboard$/);

    const cookies = await context.cookies();
    const session = cookies.find(c => c.name === 'session');
    expect(session, 'session cookie must be set').toBeDefined();
    expect(session!.httpOnly).toBe(true);
    expect(session!.secure).toBe(true);
    expect(session!.sameSite).toBe('Lax');

    // Expiry ~7 days (allow 1 day tolerance)
    const sevenDays = 7 * 24 * 60 * 60;
    const now = Math.floor(Date.now() / 1000);
    expect(session!.expires).toBeGreaterThan(now + sevenDays - 86400);
    expect(session!.expires).toBeLessThan(now + sevenDays + 86400);
  });

  test('TC-002: fails with wrong password @P0 @negative', async ({ page, context }) => {
    const login = new LoginPage(page);
    await login.goto();
    await login.login(USER, 'WrongPass999');

    await expect(login.errorMessage).toHaveText(/invalid credentials/i);
    await expect(page).toHaveURL(/\/login$/);
    const cookies = await context.cookies();
    expect(cookies.find(c => c.name === 'session')).toBeUndefined();
  });

  test('TC-003: same error for unknown email (no user enumeration) @P0 @security', async ({ page }) => {
    const login = new LoginPage(page);
    await login.goto();
    await login.login('ghost@nowhere.com', 'anything123');

    // Must be EXACTLY the same text as TC-002
    await expect(login.errorMessage).toHaveText('Invalid credentials');
  });

  test('TC-004: session cookie has correct security flags @P0 @security', async ({ page, context }) => {
    const login = new LoginPage(page);
    await login.goto();
    await login.login(USER, PASS);
    await expect(page).toHaveURL(/\/dashboard$/);

    const session = (await context.cookies()).find(c => c.name === 'session')!;
    expect(session.httpOnly, 'HttpOnly').toBe(true);
    expect(session.secure, 'Secure').toBe(true);
    expect(session.sameSite, 'SameSite').toBe('Lax');
  });
});

test.describe('REQ-2: Input validation', () => {
  test('TC-005: Sign In disabled when email empty @P1 @functional', async ({ page }) => {
    const login = new LoginPage(page);
    await login.goto();
    await login.fillPassword('ValidPass123!');
    await expect(login.signInButton).toBeDisabled();
  });

  test('TC-006: Sign In disabled when password empty @P1 @functional', async ({ page }) => {
    const login = new LoginPage(page);
    await login.goto();
    await login.fillEmail(USER);
    await expect(login.signInButton).toBeDisabled();
  });

  test('TC-007: rejects malformed email on blur @P1 @boundary', async ({ page }) => {
    const login = new LoginPage(page);
    await login.goto();
    await login.fillEmail('not-an-email');
    await login.emailInput.blur();
    await expect(login.page.getByText(/valid email/i)).toBeVisible();
  });

  test('TC-009: rejects SQL injection in email @P0 @security', async ({ page, context }) => {
    const login = new LoginPage(page);
    await login.goto();
    await login.login("admin' OR '1'='1", 'anything');
    await expect(login.errorMessage).toHaveText(/invalid credentials/i);
    expect((await context.cookies()).find(c => c.name === 'session')).toBeUndefined();
  });

  test('TC-010: escapes XSS payload in email @P0 @security', async ({ page }) => {
    let dialogFired = false;
    page.on('dialog', () => { dialogFired = true; });

    const login = new LoginPage(page);
    await login.goto();
    await login.login('<script>alert(1)</script>@x.com', 'anything');

    await expect(login.errorMessage).toBeVisible();
    expect(dialogFired, 'no alert() should ever fire').toBe(false);
    // Reflected text should be escaped — no <script> nodes injected
    const scripts = await page.locator('body script').count();
    expect(scripts).toBe(0);
  });
});

test.describe('REQ-5: Accessibility', () => {
  test('TC-022: login page has no WCAG AA violations @P1 @accessibility', async ({ page }) => {
    await new LoginPage(page).goto();
    const results = await new AxeBuilder({ page }).withTags(['wcag2a', 'wcag2aa']).analyze();
    expect(results.violations, JSON.stringify(results.violations, null, 2)).toEqual([]);
  });

  test('TC-023: keyboard-only login works @P1 @accessibility', async ({ page }) => {
    await page.goto('/login');
    await page.keyboard.press('Tab'); // focus skip-link or first field
    // Type into whichever field is focused first, then Tab to next
    await page.keyboard.type(USER);
    await page.keyboard.press('Tab');
    await page.keyboard.type(PASS);
    await page.keyboard.press('Enter');
    await expect(page).toHaveURL(/\/dashboard$/);
  });
});
