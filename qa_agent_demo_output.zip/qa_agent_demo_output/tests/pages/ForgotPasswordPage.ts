import { Page, Locator, expect } from '@playwright/test';

export class ForgotPasswordPage {
  readonly page: Page;
  readonly emailInput: Locator;
  readonly submitButton: Locator;
  readonly confirmationMessage: Locator;

  constructor(page: Page) {
    this.page = page;
    this.emailInput = page.getByLabel(/email/i);
    this.submitButton = page.getByRole('button', { name: /send reset link/i });
    // The app shows the same message regardless of whether the email exists (REQ-4).
    this.confirmationMessage = page.getByText(/if the email exists/i);
  }

  async goto() {
    await this.page.goto('/forgot-password');
    await expect(this.emailInput).toBeVisible();
  }

  async requestReset(email: string) {
    await this.emailInput.fill(email);
    await this.submitButton.click();
  }
}

export class ResetPasswordPage {
  readonly page: Page;
  readonly newPasswordInput: Locator;
  readonly submitButton: Locator;
  readonly errorMessage: Locator;
  readonly successMessage: Locator;

  constructor(page: Page) {
    this.page = page;
    this.newPasswordInput = page.getByLabel(/new password/i);
    this.submitButton = page.getByRole('button', { name: /reset password/i });
    this.errorMessage = page.getByRole('alert');
    this.successMessage = page.getByText(/password (has been )?reset/i);
  }

  async goto(token: string) {
    await this.page.goto(`/reset-password?token=${encodeURIComponent(token)}`);
  }

  async resetPassword(newPassword: string) {
    await this.newPasswordInput.fill(newPassword);
    await this.submitButton.click();
  }
}
