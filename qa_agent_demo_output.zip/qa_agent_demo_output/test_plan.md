# Test Plan: User Login & Password Reset

## 1. Scope

This plan covers end-to-end QA of the email/password authentication flow for web
(REQ-1 through REQ-5), including login, input validation, rate limiting, password
reset, and accessibility. Both the browser-facing UI and the backing REST API are
in scope. Out of scope: SSO/OAuth, 2FA, and account-lockout email notifications —
these are deferred to Phase 2.

## 2. Test Objectives

| Objective | Requirements |
|-----------|--------------|
| Verify a valid user can log in and reach `/dashboard` | REQ-1 |
| Verify credentials are never leaked via timing or error messages | REQ-1 |
| Verify client AND server validate email/password shape | REQ-2 |
| Verify rate limiting triggers at the 6th failed attempt and resets correctly | REQ-3 |
| Verify password reset flow works end-to-end and tokens are single-use | REQ-4 |
| Verify all auth pages are accessible (WCAG AA, keyboard, screen reader) | REQ-5 |
| Verify all three API endpoints match their contract | REQ-1, REQ-3, REQ-4 |

## 3. Test Approach

- **System testing** — primary level; exercise the real UI and API
- **Integration testing** — API endpoints tested independently with `request` fixture
- **Functional testing** — all positive and negative paths
- **Security testing** — SQLi, XSS, auth bypass, user enumeration, CSRF, rate-limit evasion
- **Accessibility testing** — axe-core scan + manual keyboard/screen reader spot checks (REQ-5)
- **Regression testing** — the full P0/P1 suite runs on every PR in CI

Performance testing (load, soak) is NOT planned for this release — REQ-4's 30s reset
SLA will be verified with a single-user timing check only.

## 4. Features To Test

- REQ-1: Login form UI and `POST /api/auth/login` endpoint
- REQ-2: Client-side field validation + server-side re-validation
- REQ-3: Rate limiter (6th attempt → 429, Retry-After header, 15-min reset, success reset)
- REQ-4: Forgot-password flow, reset token security, reset page
- REQ-5: Accessibility of `/login`, `/forgot-password`, `/reset-password`

## 5. Features NOT To Test

| Feature | Justification |
|---------|---------------|
| SSO / OAuth | Out of scope (Phase 2) |
| 2FA | Out of scope (Phase 2) |
| Email deliverability / spam-folder routing | Infrastructure concern; covered by ops monitoring |
| bcrypt cost parameter | Implementation detail; verified at unit-test level |
| Session cookie cross-domain | Single-domain app |

## 6. Entry & Exit Criteria

**Entry:**
- Dev build deployed to staging with all REQ-1..5 implemented
- Test user accounts provisioned in staging DB
- `BASE_URL` and `API_URL` reachable from CI runners

**Exit:**
- 100% of P0 cases pass
- ≥ 95% of P1 cases pass
- Zero P0 or P1 bugs open
- Accessibility scan shows no WCAG AA violations on auth pages
- Sign-off from QA lead + Product owner

## 7. Test Environments

- **Browsers:** Chromium, Firefox, WebKit (Playwright defaults)
- **Viewport:** Desktop 1280x720 primary; mobile 390x844 smoke
- **OS:** Linux CI runners; developers run locally on macOS/Windows
- **Test data:** 3 seeded users — `active@test.com`, `locked@test.com`, `reset@test.com`
- **Services required:** app server, auth API, test mailbox (MailHog in staging)

## 8. Risks & Mitigations

| ID | Risk | Likelihood | Impact | Mitigation |
|----|------|------------|--------|------------|
| R1 | Rate limiter (REQ-3) may lock out legitimate users sharing an IP (office NAT) | Medium | High | Limiter keyed by email, not IP — verify with TC covering two emails from same IP |
| R2 | "Invalid credentials" message may differ by microseconds between "no such user" and "wrong password" → user enumeration | Medium | High | Add timing-attack test (TC-013) |
| R3 | Reset token entropy may be weaker than 32 bytes in practice | Low | High | Inspect actual token length/charset in TC-020 |
| R4 | Accessibility regressions easy to miss as UI evolves | High | Medium | Automate axe-core in CI on every PR |
| R5 | Reset email SLA (30s) depends on external queue — flaky tests | High | Low | Mark TC-021 as manual; monitor in ops dashboards, not CI |

## 9. Deliverables

1. `test_plan.md` — this document
2. `test_cases.json` — structured test cases
3. Automated Playwright suite (TypeScript) under `tests/`
4. `AUTOMATION_REPORT.md` — generation summary
5. Bug reports filed in Jira (if any found during execution)
6. Final sign-off note to Product owner

## 10. Schedule Estimate

| Phase | Duration |
|-------|----------|
| Test plan review & sign-off | 0.5 day |
| Test case design + review | 1 day |
| Automation implementation | 2 days |
| Test execution + bug cycle | 2 days |
| Accessibility & security verification | 1 day |
| Regression + sign-off | 0.5 day |
| **Total** | **~7 person-days** |
