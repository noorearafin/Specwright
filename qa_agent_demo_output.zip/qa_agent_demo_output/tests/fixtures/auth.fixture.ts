import { test as base, Page } from '@playwright/test';
import { LoginPage } from '../pages/LoginPage';

type AuthedFixtures = {
  loggedInPage: Page;
};

/**
 * Provides a pre-authenticated page. Logs in once and reuses storage state.
 * Usage:
 *   import { test, expect } from '../fixtures/auth.fixture';
 *   test('something', async ({ loggedInPage }) => { ... });
 */
export const test = base.extend<AuthedFixtures>({
  loggedInPage: async ({ browser }, use) => {
    const context = await browser.newContext();
    const page = await context.newPage();
    const login = new LoginPage(page);
    await login.goto();
    await login.login(
      process.env.TEST_USER ?? 'active@test.com',
      process.env.TEST_PASS ?? 'ValidPass123!',
    );
    await page.waitForURL(/\/dashboard$/);
    await use(page);
    await context.close();
  },
});

export { expect } from '@playwright/test';
