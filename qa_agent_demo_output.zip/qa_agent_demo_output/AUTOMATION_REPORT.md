# Automation Report

Generated 22 automated test cases from 24 total (2 marked manual-only, justified below).
Project scaffolded from scratch — `playwright.config.ts`, `package.json`, `tsconfig.json`
created. Structure follows Page Object Model with clean separation of UI and API specs.

## Files Written (10)

- `package.json`
- `tsconfig.json`
- `playwright.config.ts`
- `.env.example`
- `README.md`
- `tests/pages/LoginPage.ts`
- `tests/pages/ForgotPasswordPage.ts`
- `tests/specs/login.spec.ts`
- `tests/specs/password-reset.spec.ts`
- `tests/api/auth.spec.ts`
- `tests/fixtures/auth.fixture.ts`

## Cases Automated (22)

TC-001, TC-002, TC-003, TC-004, TC-005, TC-006, TC-007, TC-008, TC-009, TC-010,
TC-011, TC-012, TC-013, TC-014, TC-015, TC-016, TC-017, TC-018, TC-019, TC-020,
TC-022, TC-023

## Cases Skipped (2)

- **TC-021** — Reset email SLA (30s) requires a live mailbox. Flaky in CI; better verified by ops monitoring.
- **TC-024** — Screen reader aria-live announcement requires human verification with NVDA/VoiceOver. Automation can't reliably detect what assistive tech actually speaks.

## Known Limitations

1. **Test seam dependency.** TC-018, TC-019 assume `POST /api/test/issue-reset-token` exists in staging only. If unavailable, swap to MailHog API or skip these two.
2. **Rate-limit tests share state.** TC-013/014/015 use `Date.now()`-suffixed emails to avoid interference. If the limiter has a global (not per-email) bucket, these may still flake.
3. **Timing assertion in TC-017** uses a 500ms tolerance on enumeration-by-latency. Adjust if your infra has higher variance.

## Next Steps

```bash
npm install
npx playwright install
cp .env.example .env   # set BASE_URL, API_URL, TEST_USER, TEST_PASS
npm test
```

Run priority-filtered in CI:

```bash
npx playwright test --grep @P0   # smoke
npx playwright test --grep @P1   # full regression
```
