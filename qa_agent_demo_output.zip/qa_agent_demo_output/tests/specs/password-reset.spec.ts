import { test, expect } from '@playwright/test';
import { LoginPage } from '../pages/LoginPage';
import { ForgotPasswordPage, ResetPasswordPage } from '../pages/ForgotPasswordPage';

/**
 * REQ-4 tests. Some cases need a valid reset token — we get one via the test
 * seam `/api/test/issue-reset-token` which must be exposed in staging only.
 * In prod, this route returns 404.
 */
async function issueToken(request: import('@playwright/test').APIRequestContext, email: string): Promise<string> {
  const res = await request.post('/api/test/issue-reset-token', { data: { email } });
  expect(res.ok(), 'test seam must be enabled in staging').toBeTruthy();
  const body = await res.json();
  return body.token;
}

test.describe('REQ-4: Password reset', () => {
  test('TC-016: Forgot link navigates to /forgot-password @P1', async ({ page }) => {
    const login = new LoginPage(page);
    await login.goto();
    await login.goToForgotPassword();
    await expect(page).toHaveURL(/\/forgot-password$/);
    await expect(new ForgotPasswordPage(page).emailInput).toBeVisible();
  });

  test('TC-017: same response for existing and non-existent emails @P0 @security', async ({ page }) => {
    const forgot = new ForgotPasswordPage(page);

    // Existing email
    const t1 = Date.now();
    await forgot.goto();
    await forgot.requestReset('active@test.com');
    await expect(forgot.confirmationMessage).toBeVisible();
    const existingText = (await forgot.confirmationMessage.textContent())?.trim();
    const existingTime = Date.now() - t1;

    // Non-existent email
    const t2 = Date.now();
    await forgot.goto();
    await forgot.requestReset('ghost@nowhere.com');
    await expect(forgot.confirmationMessage).toBeVisible();
    const ghostText = (await forgot.confirmationMessage.textContent())?.trim();
    const ghostTime = Date.now() - t2;

    expect(existingText).toBe(ghostText);
    // Timing delta under 100ms to prevent enumeration via latency
    expect(Math.abs(existingTime - ghostTime)).toBeLessThan(500);
  });

  test('TC-018: reset token is single-use @P0 @security', async ({ page, request }) => {
    const token = await issueToken(request, 'reset@test.com');
    const reset = new ResetPasswordPage(page);

    // First use succeeds
    await reset.goto(token);
    await reset.resetPassword('BrandNewPass1!');
    await expect(reset.successMessage).toBeVisible();

    // Second use fails
    await reset.goto(token);
    await reset.resetPassword('AnotherPass1!');
    await expect(reset.errorMessage).toContainText(/expired|used/i);
  });

  test('TC-020: tampered/malformed token is rejected @P0 @security', async ({ page }) => {
    const reset = new ResetPasswordPage(page);
    await reset.goto('definitely-not-a-real-token');
    await reset.resetPassword('NewValidPass1!');
    await expect(reset.errorMessage).toBeVisible();
  });
});
